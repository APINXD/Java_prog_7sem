create definer = APIN@localhost view view1 as
select `mydb`.`reception`.`WorkDate_Date` AS `WorkDate_Date`,
       `mydb`.`reception`.`WorkDate_Time` AS `WorkDate_Time`,
       `mydb`.`user`.`Name`               AS `User_Name`,
       `mydb`.`user`.`FirstName`          AS `FirstName`,
       `mydb`.`user`.`MiddleName`         AS `User_MiddleName`,
       `mydb`.`user`.`Email`              AS `Email`,
       `mydb`.`employee`.`Name`           AS `Employee_Name`,
       `mydb`.`employee`.`LastName`       AS `LastName`,
       `mydb`.`employee`.`MiddleName`     AS `Employee_MiddleName`
from ((`mydb`.`reception` join `mydb`.`employee`
       on ((`mydb`.`reception`.`Employee_ID` = `mydb`.`employee`.`ID`))) join `mydb`.`user`
      on ((`mydb`.`reception`.`User_ID` = `mydb`.`user`.`ID`)))
where (`mydb`.`reception`.`company_id` = '1');

grant select on table view1 to APIN@localhost;

